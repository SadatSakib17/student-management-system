# student-management-system
A beginner-friendly Django web app to manage student records with full CRUD operations. Includes form validation, class-based views, template inheritance, and success/error messages using Django’s message framework. Built with Django and SQLite.
